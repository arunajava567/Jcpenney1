#!/bin/bash 

watch asciidoctor article.adoc

