Sample cdoe for https://github.com/spring-projects/spring-framework/issues/20239#issuecomment-457030087
