package com.jcpenney.mdc_webflux;

import reactor.core.publisher.Mono;

public class SimpleContextApp {

	public static void main(String[] args) {
		String key = "message";
		Mono<String> r = Mono.just("Reactive")
		                .flatMap( s -> Mono.subscriberContext() 
		                                   .map( ctx -> s + " " + ctx.get(key))) 
		                .subscriberContext(ctx -> ctx.put(key, "Programming")); 
		r.subscribe(System.out::println);
	
		
		String key1 = "message";

		Mono<String> r1 = Mono.subscriberContext() 
			.map( ctx -> ctx.put(key1, "Reactive Context")) 
			.flatMap( ctx -> Mono.subscriberContext()) 
			.map( ctx -> ctx.getOrDefault(key1,"Default")); 
		r1.subscribe(System.out::println);
		
		
		
		
	}

}
