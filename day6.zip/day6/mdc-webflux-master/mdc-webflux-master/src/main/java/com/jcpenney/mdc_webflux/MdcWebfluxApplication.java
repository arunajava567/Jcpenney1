package com.jcpenney.mdc_webflux;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MdcWebfluxApplication {

    public static void main(String[] args) {
        SpringApplication.run(MdcWebfluxApplication.class, args);
    }

	

}

