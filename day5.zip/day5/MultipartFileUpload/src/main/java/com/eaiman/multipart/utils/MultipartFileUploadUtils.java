package com.eaiman.multipart.utils;

public class MultipartFileUploadUtils {
    public static final String REGEX_RULES = "^01\\d{9}$|^1\\d{9}|^d{0}$";
}
