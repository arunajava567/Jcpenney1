package com.eaiman.multipart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultipartFileUploadApplication {

    public static void main(String[] args) {
        SpringApplication.run(MultipartFileUploadApplication.class, args);
    }

}
