package com.edureka.Demo1;

import org.junit.jupiter.api.Test;

import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

class MapReactiveStreamTest {

    @Test

    void mapTest1() {

        Flux.range(1, 5).map(data->data*data)

                        .subscribe(System.out::println);


        Flux.range(1, 5).map(data->data*data)

                        .subscribe(data->System.out.println(data));

    }


    @Test

    void mapTest2() {

        Flux.range(1, 5).map(data->data.toString()+"Hello").subscribe(System.out::println);

   }


    @Test

    void mapTest3() {

        Flux.range(1, 10).map(data->data*data).filter(data->data%2==0).subscribe(System.out::println);


    }


    @Test

    void mapTest4() {

        Flux<Integer> flux=Flux.just(1,2,3,4,5);

        flux.map(data->data+2).subscribe(System.out::println);

    }


    @Test

    void mapTest5() {

        Flux<String> flux = Flux.just("Tom", "Jerry");

        flux = flux.map(String::toUpperCase);


        StepVerifier.create(flux)

                    .expectNext("TOM", "JERRY")

                    .verifyComplete();

    }

}
