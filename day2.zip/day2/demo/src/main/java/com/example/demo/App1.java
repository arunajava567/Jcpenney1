package com.example.demo;



import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;


public class App1 {
    public static void main(String[] args) {

   Mono<Integer> mono1 = Mono.just(1); //0 or 1
        
        System.out.println("Mono value:"+ mono1.block());


        // Map
        // Map transforms the elements emitted by a Flux to other value by applying a synchronous function to each item.
        Flux.just(1, 5, 10)
                .map(num -> num * 10)
                .subscribe(System.out::println);

        // FlatMap
        // FlatMap transform the elements emitted by the Flux asynchronously into Publishers, then flatten these inner publishers into a single Flux through merging.
        Flux.just(1, 5, 10)
                .flatMap(num -> Flux.just(num * 10))
                .subscribe(System.out::println);


}
}
