package com.jcpenny.reactive.repository;

import com.jcpenny.reactive.model.Comment;

import reactor.core.publisher.Flux;

public interface CommentRepository {

    Flux<Comment> findAll();

}
