package com.jcpenny.reactive.repository;

import com.jcpenny.reactive.Movie;

import reactor.core.publisher.Flux;

public interface MovieRepository {

    Flux<Movie> findAll();

}
