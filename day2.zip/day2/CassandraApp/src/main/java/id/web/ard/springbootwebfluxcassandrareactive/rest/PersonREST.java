package id.web.ard.springbootwebfluxcassandrareactive.rest;

import com.datastax.driver.core.utils.UUIDs;
import id.web.ard.springbootwebfluxcassandrareactive.model.Person;
import id.web.ard.springbootwebfluxcassandrareactive.repository.PersonRepository;
import java.util.UUID;
//import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class PersonREST {
	
	@Autowired
	private PersonRepository personRepository;
	
	@GetMapping(value = "/person")
	public Flux<Person> getAllPerson() {
		return personRepository.findAll();
	}
	
	@GetMapping(value = "/person/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public Flux<Person> streamAllPerson() {
		return personRepository.findAll();
	}
	/*
	 * create table person (id uuid primary key ,name varchar,dob timestamp);
	 * {
        "id": "6919ebb0-cab1-11ea-91b0-bf61237e8567",
        "name": "ram",
        "dob": "2019-08-07T00:00:00.000+0000"
    }
	 */
	
	@PostMapping(value = "/person")  //{"id":"123e4567-e89b-12d3-a456-426614174000","name":"ram","dob":"2019-08-07"}
	public Mono<ResponseEntity<Person>> createPerson( @RequestBody Person personInput) {
		personInput.setId(UUIDs.timeBased());
		return personRepository.save(personInput).map(person -> {
			return ResponseEntity.ok(person);
		}).defaultIfEmpty(
			new ResponseEntity<>(HttpStatus.NOT_FOUND)
		);
	}

	@GetMapping(value = "/person/{id}")
	public Mono<ResponseEntity<Person>> getPersonById(@PathVariable(value = "id") String id) {
		return personRepository.findById(UUID.fromString(id)).map(person -> {
			return ResponseEntity.ok(person);
		}).defaultIfEmpty(
			new ResponseEntity<>(HttpStatus.NOT_FOUND)
		);
	}

	@PutMapping(value = "/person/{id}")
	public Mono<ResponseEntity<Person>> updatePerson(@PathVariable(value = "id") String id,  @RequestBody Person personInput) {
		return personRepository.findById(UUID.fromString(id)).flatMap(person -> {
			person.setName(personInput.getName());
			person.setDob(personInput.getDob());
			return personRepository.save(person);
		}).map(updatedPerson -> {
			return ResponseEntity.ok(updatedPerson);
		}).defaultIfEmpty(
			new ResponseEntity<>(HttpStatus.NOT_FOUND)
		);
	}

	@DeleteMapping(value = "/person/{id}")
	public Mono<ResponseEntity<Void>> deletePerson(@PathVariable(value = "id") String id) {
		return personRepository.findById(UUID.fromString(id)).flatMap(person ->
			personRepository.delete(person).then(Mono.just(new ResponseEntity<Void>(HttpStatus.OK)))
		).defaultIfEmpty(
			new ResponseEntity<>(HttpStatus.NOT_FOUND)
		);
	}
}
