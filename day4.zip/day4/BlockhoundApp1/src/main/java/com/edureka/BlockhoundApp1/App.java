package com.edureka.BlockhoundApp1;




import java.time.Duration;

import reactor.blockhound.BlockHound;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;



public class App {
	static {
		BlockHound.install();
		}

    public static void main(String[] args) {
    	
    	
    		System.out.println("begning");
    		  	  Mono.delay(Duration.ofMillis(1))
    				    .doOnNext(it -> {
    			        try {
    			            Thread.sleep(1000);
    			        }
    			        catch (InterruptedException e) {
    			           // throw new RuntimeException(e);
    			        }
    			    })
    			    .block();
    		  	System.out.println("ending");
    	    	

}
}
