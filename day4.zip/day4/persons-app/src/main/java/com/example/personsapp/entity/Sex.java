package com.example.personsapp.entity;

public enum Sex {
    MAN, WOMEN
}
