package com.example.personsapp.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Builder
@AllArgsConstructor
@Document(collection = "persons")
public class Person {

	@Id
	private String id;

	private Sex sex;
	private String firstName;
	private String lastName;
	private String age;
	private String interests;
	public Person() {}
	
	public Person(String id, Sex sex, String firstName, String lastName, String age, String interests) {
		super();
		this.id = id;
		this.sex = sex;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.interests = interests;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + ", sex=" + sex + ", firstName=" + firstName + ", lastName=" + lastName + ", age="
				+ age + ", interests=" + interests + "]";
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Sex getSex() {
		return sex;
	}
	public void setSex(Sex sex) {
		this.sex = sex;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getInterests() {
		return interests;
	}
	public void setInterests(String interests) {
		this.interests = interests;
	}
	

}
