package com.example.SpringWebFluxApp1;


import java.time.Duration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
@RestController
public class AppController {
@GetMapping("/traditionalapi")
	public Flux<Integer> getValues() { //non blocking 
		return Flux.just(1,2,3,4)     //blocking List<Integer>
				.log();
	}
@GetMapping(value="/reactiveapi1",produces=MediaType.APPLICATION_STREAM_JSON_VALUE)
	public Flux<Integer> getValues1() {  //streamed value
		return Flux.just(10,20,30,40)    //non blocking
				.delayElements(Duration.ofSeconds(5))
				.log();
	}
@GetMapping(value="/reactiveapi2",produces="text/event-stream")
	public Flux<String> getValues2() {
		return Flux.just("Ractive","Programming","Tutorial")
				.delayElements(Duration.ofSeconds(5))
				.log();
	}
}
