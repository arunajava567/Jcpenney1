package com.example.SpringWebFluxApp1;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public class WebFluxConsoleApplication {

	public static void main(String[] args) {

		   Mono<Integer> mono1 = Mono.just(1);  //0 or 1 elements can emit
	         System.out.println("Mono value:"+ mono1.block());
	         
	         
	        // Map        0 or N elements can be emited 
	        // Map transforms the elements emitted by a Flux to other value by applying a synchronous function to each item.
	        Flux.just(1, 5, 10)      
	                .map(num -> num * 10)
	                .subscribe(System.out::println);


	}

}
