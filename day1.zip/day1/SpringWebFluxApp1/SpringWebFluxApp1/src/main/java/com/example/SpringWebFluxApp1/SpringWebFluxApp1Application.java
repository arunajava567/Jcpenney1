package com.example.SpringWebFluxApp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebFluxApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebFluxApp1Application.class, args);
	}

}
