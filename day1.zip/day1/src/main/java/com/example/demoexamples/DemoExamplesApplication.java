package com.example.demoexamples;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoExamplesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoExamplesApplication.class, args);
	}

}
