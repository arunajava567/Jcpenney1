package com.example.demoexamples;

import reactor.core.publisher.Flux;


public class Buffer_operator {
    public static void main(String[] args) {

        Flux.range(1, 13) .buffer(4)
                .subscribe(e -> System.out.println("onNext: " + e));

    }
}
