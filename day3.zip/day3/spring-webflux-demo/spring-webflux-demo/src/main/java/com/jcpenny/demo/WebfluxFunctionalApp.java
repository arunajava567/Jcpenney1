package com.jcpenny.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
 
@SpringBootApplication
public class WebfluxFunctionalApp {
 
    public static void main(String[] args) {     //localhost:8086/
        SpringApplication.run(WebfluxFunctionalApp.class, args);
    }
}