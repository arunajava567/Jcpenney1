package com.milind.reactive.collector;

/**
 * Collector Class
 */
public class Temp{

    public Integer getA() {
        return a;
    }

    Integer a;

    public Temp(Integer a) {
        this.a = a;
    }
}